import * as Game from './utility.js'

console.log(` from index ${Game.generateRandomNumber(10, 100)}`)

var cars = [{"Make_ID": 440, "Make_Name": "ASTON MARTIN", "Model_ID": 1684, "Model_Name": "V8 Vantage"},{"Make_ID": 221, "Make_Name": "ASTON MARTIN", "Model_ID": 4785, "Model_Name": "V8 Vantage"},{"Make_ID": 558, "Make_Name": "ASTON MARTIN", "Model_ID": 7741, "Model_Name": "Rapide"},{"Make_ID": 440, "Make_Name": "ASTON MARTIN", "Model_ID": 1684, "Model_Name": "Rapide"},{"Make_ID": 440, "Make_Name": "ASTON MARTIN", "Model_ID": 1684, "Model_Name": "V8 Vantage"} ]

console.log(cars[3])